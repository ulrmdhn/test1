﻿# Host: localhost  (Version 5.5.5-10.1.21-MariaDB)
# Date: 2023-02-09 14:03:08
# Generator: MySQL-Front 6.0  (Build 2.20)


#
# Structure for table "barang"
#

DROP TABLE IF EXISTS `barang`;
CREATE TABLE `barang` (
  `KdBarang` char(6) NOT NULL,
  `NmBarang` varchar(35) DEFAULT NULL,
  `Satuan` varchar(10) DEFAULT NULL,
  `Stok` int(3) DEFAULT NULL,
  `harga` double(8,0) DEFAULT NULL,
  PRIMARY KEY (`KdBarang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "barang"
#

INSERT INTO `barang` VALUES ('B001','RAM 4Gb DDR3','Unit',12,250),('B002','Ram 8Gb DDR4','Unit',10,400),('B003','AMD A10','Unit',13,850),('B004','Intel I7 Gen 7770','Unit',20,2);

#
# Structure for table "detilpesan"
#

DROP TABLE IF EXISTS `detilpesan`;
CREATE TABLE `detilpesan` (
  `NoSp` char(6) NOT NULL,
  `KdBarang` char(6) NOT NULL,
  `Jmljual` int(3) DEFAULT NULL,
  `HrgJual` double(9,0) DEFAULT NULL,
  PRIMARY KEY (`NoSp`,`KdBarang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "detilpesan"
#

INSERT INTO `detilpesan` VALUES ('SP0001','B001',3,275000),('SP0001','B003',7,875000),('SP0002','B003',3,450000),('SP0002','B004',2,265000),('SP0003','B002',2,250000),('SP0003','B004',3,400000),('SP0004','B001',4,400000),('SP0004','B002',4,850000),('SP0004','B003',2,2500000),('SP0004','B004',3,850000);

#
# Structure for table "nota"
#

DROP TABLE IF EXISTS `nota`;
CREATE TABLE `nota` (
  `NoNota` char(6) NOT NULL,
  `NoSp` char(6) DEFAULT NULL,
  `JmlHarga` double(9,0) DEFAULT NULL,
  `TglNota` date DEFAULT NULL,
  PRIMARY KEY (`NoNota`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "nota"
#

INSERT INTO `nota` VALUES ('',NULL,NULL,NULL);

#
# Structure for table "pelanggan"
#

DROP TABLE IF EXISTS `pelanggan`;
CREATE TABLE `pelanggan` (
  `IdPlg` char(5) NOT NULL DEFAULT '',
  `NamaPlg` varchar(35) DEFAULT NULL,
  `Alamat` varchar(100) DEFAULT NULL,
  `NoTelp` varchar(13) DEFAULT NULL,
  `jenkel` varchar(225) DEFAULT NULL,
  `Tgl_Lahir` date DEFAULT NULL,
  PRIMARY KEY (`IdPlg`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "pelanggan"
#

INSERT INTO `pelanggan` VALUES ('P0001','Syaepul Widianto','Bogor','08288212832','Laki-Laki','1982-04-26'),('P0002','Joe Richard','Jakarta','08212882122','Laki-Laki','1972-03-27'),('P0003','Gus Samsudin','Jawa Timur','08278288129','Laki-Laki','1970-05-17'),('P0004','Christina Wisanti','Pondok Pinang','08289288218','Perempuan','1962-09-27'),('P0005','Dwi Esti Puji Astuti','Tangerang','08291288128','Perempuan','0199-08-16');

#
# Structure for table "suratpesanan"
#

DROP TABLE IF EXISTS `suratpesanan`;
CREATE TABLE `suratpesanan` (
  `NoSp` varchar(11) NOT NULL DEFAULT '',
  `Idplg` varchar(55) DEFAULT NULL,
  `tglsp` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`NoSp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "suratpesanan"
#

INSERT INTO `suratpesanan` VALUES ('SP0001','P0003','2022-07-26'),('SP0002','P0002','2022-06-30'),('SP0003','P0001','2022-06-28'),('SP0004','P0001','2022-07-30'),('SP0005','P0001','2022-07-28');

#
# Structure for table "userlogin"
#

DROP TABLE IF EXISTS `userlogin`;
CREATE TABLE `userlogin` (
  `Username` varchar(225) NOT NULL DEFAULT '',
  `Password` varchar(255) DEFAULT NULL,
  `hak_akses` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "userlogin"
#

INSERT INTO `userlogin` VALUES ('','','');

#
# Procedure "CariPelanggan"
#

DROP PROCEDURE IF EXISTS `CariPelanggan`;
CREATE PROCEDURE `CariPelanggan`(vNamaPlg Varchar (100))
begin
select * from pelanggan where NamaPlg Like CONCAT('%', vNamaPlg, '%');
end;

#
# Procedure "panggilBarang"
#

DROP PROCEDURE IF EXISTS `panggilBarang`;
CREATE PROCEDURE `panggilBarang`()
Begin
select NmBarang from barang;
end;

#
# Procedure "panggilJenkelL"
#

DROP PROCEDURE IF EXISTS `panggilJenkelL`;
CREATE PROCEDURE `panggilJenkelL`()
Begin
select * from pelanggan where jenkel='Laki-Laki';
end;
