#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
	double menuMieAyam, menuBakso, diskon, bayar, kembalian, totalHrgMieAyam, totalHrgBakso, hrgMenu1, hrgMenu2, totalPembayaran, hrg1=25000, hrg2=20000;
	
	cout<<"=================================="<<endl;
	cout<<"    >> TOKO SMK MEDIA INFORMATIKA <<" <<endl;
	cout<<"  >> Jl.Papan I/Pisangan Kretek No.99 <<" <<endl;
	cout<<" TELP.(021)22704966 kode pos 12260 <<" <<endl;
	cout<<endl;
	cout<<" Nama     :  Aulia Ramadhan"<<endl;
	cout<<" Nis      :  2021132"<<endl;
	cout<<" Kelas    :  XII-RPL-2"<<endl;
	cout<<endl;
	cout<<"=================================="<<endl;
	
	//Paker
	
	cout<<"MENU Paket 1:"<<endl;
	cout<<"1. Nasi"<<endl;
	cout<<"2. Ayam Goreng"<<endl;
	cout<<"3. Es Teh"<<endl;
	cout<<endl;
	cout<<"MENU Paket 2:"<<endl;
	cout<<"1. Nasi"<<endl;
	cout<<"2. Ayam Bakar"<<endl;
	cout<<"3. Es Teh"<<endl;
	cout<<"=================================="<<endl;
	cout<<endl;
	
	cout<<"Masukkan jumlah pembelian untuk Menu Mie Ayam : ";
	cin>>menuMieAyam;
	cout<<"                      Harga paket MENU Mie Ayam : Rp."<<hrg1<<endl;
	//cin>>MieAyam;
	hrgMenu1=hrg1*menuMieAyam;
	cout<<"                      Total harga MENU Mie Ayam : Rp."<<hrgMenu1<<endl;
	cout<<endl;
	cout<<"Masukkan jumlah pembelian untuk MENU Bakso : ";
	cin>>menuBakso;
	cout<<"                      Harga paket MENU Bakso : Rp."<<hrg2<<endl;
	hrgMenu2=hrg2*menuBakso;
	cout<<"                      Total harga MENU Bakso : Rp."<<hrgMenu2<<endl;
	
	//MENU Mie Ayam
	
	{
		if(menuMieAyam>=5&&menuMieAyam<10)
		{
			diskon=hrgMenu1*5/100;
			totalHrgMieAyam=hrgMenu1-diskon;
			cout<<endl;
			cout<<"Total pembayaran MENU Mie Ayam = "<<hrgMenu1<<"* 5% = Rp."<<totalHrgMieAyam<<endl;
		}
		else if(menuMieAyam>=10)
		{
			diskon=hrgMenu1*10/100;
			totalHrgMieAyam=hrgMenu1-diskon;
			cout<<endl;
			cout<<"Total pembayaran MENU Mie Ayam = "<<hrgMenu1<<"* 10% = Rp."<<totalHrgMieAyam<<endl;
		}
		else
		{
			totalHrgMieAyam=hrgMenu1;
			cout<<endl;
			cout<<"Total pembayaran MENU Mie Ayam = Rp."<<totalHrgMieAyam<<endl;
			cout<<"Pembelian ini tidak mendapatkan diskon"<<endl;
			cout<<endl;
		}
	}
	
	//Menu Bakso
	
		{
		if(menuBakso>=5&&menuBakso<10)
		{
			diskon=hrgMenu2*5/100;
			totalHrgBakso=hrgMenu2-diskon;
			cout<<endl;
			cout<<"Total pembayaran MENU Bakso = "<<hrgMenu2<<"* 5% = Rp."<<totalHrgBakso<<endl;
		}
		else if(menuBakso>=10)
		{
			diskon*hrgMenu2*10/100;
			totalHrgBakso=hrgMenu2-diskon;
			cout<<endl;
			cout<<"Total pembayaran MENU Bakso = "<<hrgMenu2<<"* 10% = Rp."<<totalHrgBakso<<endl;
		}
		else
		{
			totalHrgBakso=hrgMenu2;
			cout<<endl;
			cout<<"Total pembayaran MENU Bakso = Rp."<<totalHrgBakso<<endl;
			cout<<"Pembelian ini tidak mendapatkan diskon"<<endl;
			cout<<endl;
		}
	}
	
	//Total;
		cout<<endl;
		totalPembayaran=totalHrgMieAyam+totalHrgBakso;
		cout<<"Total semua yang harus dibayar = Rp."<<totalPembayaran<<endl;
		cout<<"Uang pembayaran = Rp.";
		cin>>bayar;
		kembalian=bayar-totalPembayaran;
		cout<<"Kembalian = Rp."<<kembalian;
	
	return 0;
	
	
}
